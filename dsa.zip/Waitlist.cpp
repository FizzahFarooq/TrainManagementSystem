#include <iostream>
#include "Waitlist.h"

using namespace std;

// Constructor to initialize the waitlist with a capacity
Waitlist::Waitlist(int capacity) : front(NULL), rear(NULL), size(0), capacity(capacity) {}

// Function to add a passenger to the waitlist (enqueue operation)
void Waitlist::addPassenger(int id, const string& name, const string& contact) {
    if (size == capacity) {
        cout << "Waitlist is full, cannot add passenger!" << endl;
        return;
    }
    Passenger* newPassenger = new Passenger(name, contact, id, "NoTicket", NULL);  // Pass parameters in correct order and use nullptr

    if (rear == NULL) {
        front = rear = newPassenger;
    } else {
        rear->next = newPassenger;
        rear = newPassenger;
    }
    size++;
    cout << "Passenger " << name << " added to the waitlist." << endl;
}

// Function to add a passenger to the waitlist (the interface function)
void Waitlist::addToWaitlist(const string& passengerName) {
    static int idCounter = 1;
    string contact = "Not Provided"; // Default contact info if none provided
    addPassenger(idCounter++, passengerName, contact);
}

// Function to remove the first passenger from the waitlist (dequeue operation)
void Waitlist::servePassenger() {
    if (front == NULL) {
        cout << "Waitlist is empty!" << endl;
        return;
    }
    Passenger* temp = front;
    cout << "Serving passenger " << front->name << endl;
    front = front->next;
    if (front == NULL) {
        rear = NULL;
    }
    delete temp;
    size--;
}

// Function to view the first passenger in the waitlist (peek operation)
void Waitlist::peekPassenger() {
    if (front == NULL) {
        cout << "Waitlist is empty!" << endl;
        return;
    }
    cout << "First passenger in the waitlist: " << front->name << endl;
}

// Function to display the entire waitlist
void Waitlist::displayWaitlist() {
    if (front == NULL) {
        cout << "Waitlist is empty!" << endl;
        return;
    }
    Passenger* current = front;
    cout << "Current waitlist:" << endl;
    while (current != NULL) {
        cout << "ID: " << current->id << ", Name: " << current->name << ", Contact: " << current->contact << endl;
        current = current->next;
    }
}

// Function to cancel a specific passenger (removes from the queue)
void Waitlist::cancelPassenger(int id) {
    if (front == NULL) {
        cout << "Waitlist is empty!" << endl;
        return;
    }
    Passenger* current = front;
    Passenger* prev = NULL;

    // Search for the passenger by ID
    while (current != NULL && current->id != id) {
        prev = current;
        current = current->next;
    }

    // If passenger not found
    if (current == NULL) {
        cout << "Passenger not found!" << endl;
        return;
    }

    // If passenger is at the front
    if (current == front) {
        front = front->next;
    } else {
        prev->next = current->next;
    }

    // If the passenger was at the rear
    if (current == rear) {
        rear = prev;
    }

    delete current;
    size--;
    cout << "Passenger with ID " << id << " has been removed from the waitlist." << endl;
}

// Destructor to clean up memory
Waitlist::~Waitlist() {
    while (front != NULL) {
        Passenger* temp = front;
        front = front->next;
        delete temp;
    }
}

