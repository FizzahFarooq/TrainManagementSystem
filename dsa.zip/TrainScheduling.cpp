#include "TrainScheduling.h"
#include <iostream>
#include <stdexcept>

TrainSchedule::TrainSchedule(string trainID, string departureTime, string arrivalTime, bool isVIP)
    : trainID(trainID), departureTime(departureTime), arrivalTime(arrivalTime), isVIP(isVIP) {}

bool TrainSchedule::operator<(const TrainSchedule& other) const {
    if (this->isVIP != other.isVIP) {
        return this->isVIP > other.isVIP; // VIP trains should come first
    }
    return this->departureTime < other.departureTime; // Compare by departure time
}

void TrainSchedule::display() const {
    cout << "TrainID: " << trainID << ", Departure: " << departureTime
         << ", Arrival: " << arrivalTime << (isVIP ? " (VIP)" : "") << endl;
}

TrainScheduling::TrainScheduling() {}

int TrainScheduling::parent(int index) {
    return (index - 1) / 2;
}

int TrainScheduling::leftChild(int index) {
    return 2 * index + 1;
}

int TrainScheduling::rightChild(int index) {
    return 2 * index + 2;
}

void TrainScheduling::heapifyUp(int index) {
    while (index > 0 && heap[index] < heap[parent(index)]) {
        swap(heap[index], heap[parent(index)]);
        index = parent(index);
    }
}

void TrainScheduling::heapifyDown(int index) {
    int left = leftChild(index);
    int right = rightChild(index);
    int smallest = index;

    if (left < heap.size() && heap[left] < heap[smallest]) {
        smallest = left;
    }
    if (right < heap.size() && heap[right] < heap[smallest]) {
        smallest = right;
    }
    if (smallest != index) {
        swap(heap[index], heap[smallest]);
        heapifyDown(smallest);
    }
}

void TrainScheduling::addTrainSchedule(string trainID, string departureTime, string arrivalTime, bool isVIP) {
    TrainSchedule newTrain(trainID, departureTime, arrivalTime, isVIP);
    heap.push_back(newTrain);  // Add new train schedule at the end
    heapifyUp(heap.size() - 1);  // Ensure the heap property by bubbling up
}

TrainSchedule TrainScheduling::removeHighestPriority() {
    if (heap.empty()) {
        throw runtime_error("Heap is empty!");
    }

    TrainSchedule minTrain = heap[0];
    heap[0] = heap.back();  // Move the last element to the root
    heap.pop_back();  // Remove the last element
    heapifyDown(0);  // Restore heap property by bubbling down

    return minTrain;
}

void TrainScheduling::displaySchedule() const {
    cout << "Train Schedules: " << endl;
    for (size_t i = 0; i < heap.size(); ++i) {
        heap[i].display();  // Display each train schedule
    }
}

int TrainScheduling::scheduleCount() const {
    return heap.size();
}

bool TrainScheduling::isEmpty() const {
    return heap.empty();
}

