#include "RevenueManagement.h"

// Private helper methods

int RevenueManagement::getHeight(RevenueRecord* node) {
    if (node == NULL) return 0;
    return node->height;
}

void RevenueManagement::updateHeight(RevenueRecord* node) {
    node->height = max(getHeight(node->left), getHeight(node->right)) + 1;
}

int RevenueManagement::getBalance(RevenueRecord* node) {
    if (node == NULL) return 0;
    return getHeight(node->left) - getHeight(node->right);
}

RevenueRecord* RevenueManagement::rightRotate(RevenueRecord* y) {
    RevenueRecord* x = y->left;
    RevenueRecord* T2 = x->right;

    x->right = y;
    y->left = T2;

    updateHeight(y);
    updateHeight(x);

    return x;
}

RevenueRecord* RevenueManagement::leftRotate(RevenueRecord* x) {
    RevenueRecord* y = x->right;
    RevenueRecord* T2 = y->left;

    y->left = x;
    x->right = T2;

    updateHeight(x);
    updateHeight(y);

    return y;
}

RevenueRecord* RevenueManagement::insert(RevenueRecord* node, string tID, string tDate, double rev) {
    if (node == NULL) {
        return new RevenueRecord(tID, tDate, rev);
    }

    if (tID < node->trainID) {
        node->left = insert(node->left, tID, tDate, rev);
    } else if (tID > node->trainID) {
        node->right = insert(node->right, tID, tDate, rev);
    } else {
        return node; // Duplicate IDs are not allowed
    }

    updateHeight(node);

    int balance = getBalance(node);

    if (balance > 1 && tID < node->left->trainID) {
        return rightRotate(node);
    }

    if (balance < -1 && tID > node->right->trainID) {
        return leftRotate(node);
    }

    if (balance > 1 && tID > node->left->trainID) {
        node->left = leftRotate(node->left);
        return rightRotate(node);
    }

    if (balance < -1 && tID < node->right->trainID) {
        node->right = rightRotate(node->right);
        return leftRotate(node);
    }

    return node;
}

RevenueRecord* RevenueManagement::search(RevenueRecord* node, string tID) {
    if (node == NULL || node->trainID == tID) {
        return node;
    }

    if (tID < node->trainID) {
        return search(node->left, tID);
    }

    return search(node->right, tID);
}

void RevenueManagement::inorder(RevenueRecord* root) {
    if (root != NULL) {
        inorder(root->left);
        cout << "Train ID: " << root->trainID << ", Date: " << root->travelDate << ", Revenue: " << root->revenue << endl;
        inorder(root->right);
    }
}

void RevenueManagement::deallocate(RevenueRecord* node) {
    if (node == NULL) return;
    deallocate(node->left);
    deallocate(node->right);
    delete node;
}

// Public methods

RevenueManagement::RevenueManagement() : root(NULL) {}

void RevenueManagement::insertRevenueRecord(string tID, string tDate, double rev) {
    root = insert(root, tID, tDate, rev);
}

void RevenueManagement::searchRevenueRecord(string tID) {
    RevenueRecord* record = search(root, tID);
    if (record != NULL) {
        cout << "Train ID: " << record->trainID << ", Date: " << record->travelDate << ", Revenue: " << record->revenue << endl;
    } else {
        cout << "Revenue record not found." << endl;
    }
}

void RevenueManagement::displayRevenueRecords() {
    inorder(root);
}

RevenueManagement::~RevenueManagement() {
    deallocate(root);
}

