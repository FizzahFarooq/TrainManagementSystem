#ifndef TRAIN_MAINTENANCE_H
#define TRAIN_MAINTENANCE_H

#include <string>
using namespace std;

// Structure to represent a Maintenance record
struct MaintenanceRecord {
    string maintenanceID;
    string trainID;
    string maintenanceDate;
    string description;
    MaintenanceRecord* next;
    MaintenanceRecord* prev;

    MaintenanceRecord(string mID, string tID, string mDate, string desc);
};

// Class to represent the doubly linked list of maintenance records
class TrainMaintenance {
private:
    MaintenanceRecord* head;
    MaintenanceRecord* tail;

public:
    TrainMaintenance();

    // Add a new maintenance record at the end of the list
    void addMaintenanceRecord(string mID, string tID, string mDate, string desc);

    // Remove the most recent maintenance record (tail)
    void removeRecentMaintenance();

    // Display all maintenance records from the most recent to the oldest
    void displayMaintenanceRecords();

    // Search for a specific maintenance record by its ID
    void searchMaintenanceRecordByID(string mID);

    // Update a maintenance record (based on maintenance ID)
    void updateMaintenanceRecord(string mID, string newDesc);

    // Destructor to clean up the dynamically allocated memory
    ~TrainMaintenance();
};

#endif // TRAIN_MAINTENANCE_H

