#include "TrainRoutesManagement.h"

// Constructor to initialize the number of stations and the adjacency matrix
TrainRoutesManagement::TrainRoutesManagement(int stations) {
    numStations = stations;
    adjMatrix = new int*[stations];  // Dynamically allocate memory for rows
    for (int i = 0; i < stations; ++i) {
        adjMatrix[i] = new int[stations];  // Dynamically allocate memory for columns
    }

    // Initialize the adjacency matrix
    for (int i = 0; i < stations; ++i) {
        for (int j = 0; j < stations; ++j) {
            adjMatrix[i][j] = (i == j) ? 0 : INT_MAX;  // No travel time to self, INT_MAX for others
        }
    }
}

// Destructor to release dynamically allocated memory
TrainRoutesManagement::~TrainRoutesManagement() {
    for (int i = 0; i < numStations; ++i) {
        delete[] adjMatrix[i];  // Deallocate each row
    }
    delete[] adjMatrix;  // Deallocate the array of rows
}

// Add a route between two stations with a specific travel time
void TrainRoutesManagement::addRoute(int station1, int station2, int travelTime) {
    adjMatrix[station1][station2] = travelTime;
    adjMatrix[station2][station1] = travelTime;  // Assuming undirected graph (both directions)
}

// Remove a route between two stations
void TrainRoutesManagement::removeRoute(int station1, int station2) {
    adjMatrix[station1][station2] = INT_MAX;
    adjMatrix[station2][station1] = INT_MAX;  // Remove both directions
}

// Custom comparator for the priority queue (compare by distance)
bool TrainRoutesManagement::Compare::operator()(pair<int, int>& p1, pair<int, int>& p2) {
    return p1.first > p2.first;  // Compare by the first element (distance)
}

// Dijkstra's algorithm to find the shortest path from a source station to all other stations
void TrainRoutesManagement::dijkstra(int source) {
    int* dist = new int[numStations];  // Array to store distances from source
    for (int i = 0; i < numStations; ++i) {
        dist[i] = INT_MAX;
    }
    dist[source] = 0;

    // Using custom comparator in priority queue
    priority_queue<pair<int, int>, vector<pair<int, int> >, Compare> pq;
    pq.push(pair<int, int>(0, source));  // Push the source station with distance 0

    while (!pq.empty()) {
        int u = pq.top().second;
        pq.pop();

        // Traverse all adjacent stations (v)
        for (int v = 0; v < numStations; ++v) {
            // Check if the station v is reachable and if the path is shorter
            if (adjMatrix[u][v] != INT_MAX && dist[u] + adjMatrix[u][v] < dist[v]) {
                dist[v] = dist[u] + adjMatrix[u][v];
                pq.push(pair<int, int>(dist[v], v));  // Push the updated distance to the priority queue
            }
        }
    }

    // Print the shortest distances from the source station
    cout << "Shortest distances from station " << source << ":" << endl;
    for (int i = 0; i < numStations; ++i) {
        if (dist[i] == INT_MAX) {
            cout << "Station " << i << " is unreachable." << endl;
        } else {
            cout << "To Station " << i << ": " << dist[i] << " minutes" << endl;
        }
    }

    delete[] dist;  // Free the dynamically allocated memory for dist
}

// Floyd-Warshall algorithm for all-pairs shortest paths
void TrainRoutesManagement::floydWarshall() {
    int** dist = new int*[numStations];  // Allocate memory for the distance matrix
    for (int i = 0; i < numStations; ++i) {
        dist[i] = new int[numStations];
    }

    // Copy the adjacency matrix to the distance matrix
    for (int i = 0; i < numStations; ++i) {
        for (int j = 0; j < numStations; ++j) {
            dist[i][j] = adjMatrix[i][j];
        }
    }

    // Run the Floyd-Warshall algorithm
    for (int k = 0; k < numStations; ++k) {
        for (int i = 0; i < numStations; ++i) {
            for (int j = 0; j < numStations; ++j) {
                if (dist[i][k] != INT_MAX && dist[k][j] != INT_MAX && dist[i][k] + dist[k][j] < dist[i][j]) {
                    dist[i][j] = dist[i][k] + dist[k][j];  // Update the shortest distance
                }
            }
        }
    }

    // Print the shortest distances between all pairs of stations
    cout << "Shortest distances between all pairs of stations:" << endl;
    for (int i = 0; i < numStations; ++i) {
        for (int j = 0; j < numStations; ++j) {
            if (dist[i][j] == INT_MAX) {
                cout << "Station " << i << " to Station " << j << " is unreachable." << endl;
            } else {
                cout << "From Station " << i << " to Station " << j << ": " << dist[i][j] << " minutes" << endl;
            }
        }
    }

    // Free dynamically allocated memory
    for (int i = 0; i < numStations; ++i) {
        delete[] dist[i];
    }
    delete[] dist;
}

