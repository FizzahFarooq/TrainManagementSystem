#ifndef TICKETRESERVATIONSYSTEM_H
#define TICKETRESERVATIONSYSTEM_H

#include <queue>
#include <string>
#include <vector>
#include "Passenger.h"  // Include this to use the Passenger class

using namespace std;

class TicketReservationSystem {
private:
    queue<Passenger> reservationQueue;  // Queue to store passenger reservations
    vector<bool> seatAvailability;      // Tracks seat availability
    int totalSeats;

public:
    // Default constructor
    TicketReservationSystem();

    // Constructor to initialize the system with total seats
    TicketReservationSystem(int totalSeats);

    // Check if there are available seats
    bool hasAvailableSeat() const;

    // Function to reserve a ticket for a passenger
    void reserveTicket(string ticketID, string name, string reservationTime);

    // Function to confirm the next passenger's reservation from the queue
    void confirmTicket();

    // Function to display all reservations in the queue
    void displayReservations() const;

    // Function to check available seats
    void showAvailableSeats() const;
};

#endif

