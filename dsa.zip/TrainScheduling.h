#ifndef TRAINSCHEDULING_H
#define TRAINSCHEDULING_H

#include <string>
#include <vector>
using namespace std;

// TrainSchedule class to represent each train's schedule
class TrainSchedule {
public:
    string trainID;
    string departureTime;
    string arrivalTime;
    bool isVIP; // VIP status

    // Constructor to initialize train schedule
    TrainSchedule(string trainID, string departureTime, string arrivalTime, bool isVIP = false);

    // Comparator for sorting by departure time and VIP status
    bool operator<(const TrainSchedule& other) const;

    // Display train schedule details
    void display() const;
};

// TrainScheduling class to manage the train schedules
class TrainScheduling {
private:
    vector<TrainSchedule> heap; // Min-heap to store train schedules

    int parent(int index);
    int leftChild(int index);
    int rightChild(int index);

    // Maintain the heap property by bubbling up
    void heapifyUp(int index);

    // Maintain the heap property by bubbling down
    void heapifyDown(int index);

public:
    TrainScheduling();

    // Add a new train schedule to the priority queue (min-heap)
    void addTrainSchedule(string trainID, string departureTime, string arrivalTime, bool isVIP = false);

    // Remove and return the highest-priority element (earliest departure time or VIP)
    TrainSchedule removeHighestPriority();

    // Display the entire train schedule
    void displaySchedule() const;

    // Get the number of trains in the schedule
    int scheduleCount() const;

    // Check if the schedule is empty
    bool isEmpty() const;
};

#endif // TRAINSCHEDULING_H

