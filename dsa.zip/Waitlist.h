#ifndef WAITLIST_H
#define WAITLIST_H

#include <string>

class Passenger {
public:
    std::string name;
    std::string contact;
    int id;
    std::string ticketStatus;
    Passenger* next;

    Passenger(std::string name, std::string contact, int id, std::string ticketStatus, Passenger* next)
        : name(name), contact(contact), id(id), ticketStatus(ticketStatus), next(next) {}
};

class Waitlist {
private:
    Passenger* front;
    Passenger* rear;
    int size;
    int capacity;

public:
    // Constructor
    Waitlist(int capacity);

    // Add a passenger to the waitlist
    void addPassenger(int id, const std::string& name, const std::string& contact);

    // Add a passenger to the waitlist (interface function)
    void addToWaitlist(const std::string& passengerName);

    // Remove the first passenger from the waitlist
    void servePassenger();

    // View the first passenger in the waitlist
    void peekPassenger();

    // Display the entire waitlist
    void displayWaitlist();

    // Cancel a specific passenger
    void cancelPassenger(int id);

    // Destructor
    ~Waitlist();
};

#endif // WAITLIST_H

