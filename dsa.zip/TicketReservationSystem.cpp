#include "TicketReservationSystem.h"
#include <iostream>

using namespace std;

// Default constructor
TicketReservationSystem::TicketReservationSystem() {
    totalSeats = 10;  // Default to 10 seats
    seatAvailability.resize(totalSeats, true); // Initially, all seats are available
}

// Constructor to initialize the system with total seats
TicketReservationSystem::TicketReservationSystem(int totalSeats) {
    this->totalSeats = totalSeats;
    seatAvailability.resize(totalSeats, true); // Initially, all seats are available
}

// Check if there are available seats
bool TicketReservationSystem::hasAvailableSeat() const {
    for (size_t i = 0; i < seatAvailability.size(); ++i) {
        if (seatAvailability[i]) {
            return true;  // At least one available seat
        }
    }
    return false;  // No available seats
}

// Function to reserve a ticket for a passenger
void TicketReservationSystem::reserveTicket(string ticketID, string name, string reservationTime) {
    if (!hasAvailableSeat()) {
        cout << "Sorry, no seats are available at the moment." << endl;
        return;
    }

    // Find the first available seat
    int seatNumber = -1;
    for (int i = 0; i < totalSeats; ++i) {
        if (seatAvailability[i]) {
            seatNumber = i;
            seatAvailability[i] = false;  // Mark the seat as reserved
            break;
        }
    }

    // Add the passenger's reservation to the queue
    Passenger newPassenger(ticketID, name, seatNumber, reservationTime);
    reservationQueue.push(newPassenger);

    cout << "Reservation successful! Seat number: " << seatNumber + 1 << endl;
}

// Function to confirm the next passenger's reservation from the queue
void TicketReservationSystem::confirmTicket() {
    if (reservationQueue.empty()) {
        cout << "No reservations to process." << endl;
        return;
    }

    // Get the passenger at the front of the queue
    Passenger nextPassenger = reservationQueue.front();
    reservationQueue.pop();

    cout << "Ticket confirmed for passenger: " << nextPassenger.name << endl;
    cout << "Ticket ID: " << nextPassenger.ticketID << ", Seat: " << nextPassenger.seatNumber + 1 << endl;
    cout << "Reservation Time: " << nextPassenger.reservationTime << endl;
}

// Function to display all reservations in the queue
void TicketReservationSystem::displayReservations() const {
    if (reservationQueue.empty()) {
        cout << "No current reservations." << endl;
        return;
    }

    cout << "Current reservations in the queue:" << endl;
    queue<Passenger> tempQueue = reservationQueue;
    while (!tempQueue.empty()) {
        Passenger p = tempQueue.front();
        tempQueue.pop();
        cout << "Ticket ID: " << p.ticketID << ", Name: " << p.name
             << ", Seat: " << p.seatNumber + 1 << ", Reservation Time: " << p.reservationTime << endl;
    }
}

// Function to check available seats
void TicketReservationSystem::showAvailableSeats() const {
    cout << "Available seats: ";
    for (int i = 0; i < totalSeats; ++i) {
        if (seatAvailability[i]) {
            cout << i + 1 << " ";  // Display available seat number (1-indexed)
        }
    }
    cout << endl;
}

