#ifndef TRAINROUTESMANAGEMENT_H
#define TRAINROUTESMANAGEMENT_H

#include <iostream>
#include <limits.h>  // for INT_MAX
#include <queue>
#include <vector>

using namespace std;

class TrainRoutesManagement {
private:
    int** adjMatrix;  // Adjacency matrix to store travel times between stations
    int numStations;  // Number of stations

public:
    // Constructor to initialize the number of stations and the adjacency matrix
    TrainRoutesManagement(int stations);

    // Destructor to release dynamically allocated memory
    ~TrainRoutesManagement();

    // Add a route between two stations with a specific travel time
    void addRoute(int station1, int station2, int travelTime);

    // Remove a route between two stations
    void removeRoute(int station1, int station2);

    // Dijkstra's algorithm to find the shortest path from a source station to all other stations
    void dijkstra(int source);

    // Floyd-Warshall algorithm for all-pairs shortest paths
    void floydWarshall();

    // Custom comparator for the priority queue (compare by distance)
    struct Compare {
        bool operator()(pair<int, int>& p1, pair<int, int>& p2);
    };
};

#endif

