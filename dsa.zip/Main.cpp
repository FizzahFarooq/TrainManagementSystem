#include <iostream>
#include <vector>
#include "Passenger.h"
#include "TrainScheduling.h"
#include "PassengerManagement.h"
#include "TrainRoutesManagement.h"
#include "TicketReservationSystem.h"
#include "SeatAllocation.h"
#include "TrainDelaysTracking.h"
#include "Waitlist.h"
#include "AnalyticsAndReporting.h"
#include "TrainMaintenance.h"
#include "RevenueManagement.h"
#include "AdminLogin.h"
#include "RouteOptimization.h"

using namespace std;

int main() {
    vector<string> stations;
    stations.push_back("Karachi");
    stations.push_back("Rawalpindi");
    stations.push_back("Islamabad");
    stations.push_back("Lahore");
    stations.push_back("Peshawar");

    TrainScheduling trainScheduler;
    PassengerManagement passengerSystem;
    TrainRoutesManagement routes(5); 
    TicketReservationSystem ticketSystem;
    SeatAllocation seatSystem(60);
    TrainDelaysTracking delaysSystem;
    Waitlist waitlist(5);
    AnalyticsAndReporting analytics;
    TrainMaintenance maintenanceSystem;
    RevenueManagement revenueSystem;
    AdminLogin admin;
    RouteOptimization routeOptimizer;

    int choice;
    bool isAdminLoggedIn = false;

    while (true) {
        cout << "\n===== Welcome to Train Reservation System =====\n";
        cout << "1. User Menu\n";
        cout << "2. Admin Menu\n";
        cout << "3. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        if (choice == 1) {
            int userChoice;
            cout << "\n===== User Menu =====\n";
            cout << "1. View Available Trains\n";
            cout << "2. Book Ticket\n";
            cout << "3. View Seat Availability\n";
            cout << "4. View Train Delays\n";
            cout << "5. Optimize Route\n";
            cout << "6. Exit\n";
            cout << "Enter your choice: ";
            cin >> userChoice;

            if (userChoice == 1) {
                trainScheduler.displaySchedule();
            } else if (userChoice == 2) {
                string trainID, passengerName;
                int seatNumber;
                cout << "Enter Train ID: ";
                cin >> trainID;
                cout << "Enter Passenger Name: ";
                cin >> passengerName;
                cout << "Enter Seat Number: ";
                cin >> seatNumber;

                if (seatSystem.allocateSeat(passengerName)) {
                    passengerSystem.addPassenger(trainID + "-" + passengerName, passengerName, to_string(seatNumber));
                    ticketSystem.reserveTicket(trainID, passengerName, seatNumber);
                    cout << "Ticket booked successfully!" << endl;
                } else {
                    cout << "No available seats! Adding to waitlist...\n";
                    waitlist.addToWaitlist(passengerName);  // Now this will work
                }
            } else if (userChoice == 3) {
                seatSystem.displaySeats();
            } else if (userChoice == 4) {
                delaysSystem.displayAllDelays();
            } else if (userChoice == 5) {
                int sourceStation = 0; // Example: Karachi (index 0)
                routeOptimizer.optimizeRoute(sourceStation); // Pass the source station
            } else {
                break;
            }

        } else if (choice == 2 && !isAdminLoggedIn) {
            string username, password;
            cout << "\nEnter Admin Username: ";
            cin >> username;
            cout << "Enter Admin Password: ";
            cin >> password;

            if (admin.login(username, password)) {
                isAdminLoggedIn = true;
                cout << "Admin login successful!" << endl;
            } else {
                cout << "Invalid credentials!" << endl;
            }

        } else if (choice == 2 && isAdminLoggedIn) {
            int adminChoice;
            cout << "\n===== Admin Menu =====\n";
            cout << "1. Add New Train\n";
            cout << "2. View Revenue\n";
            cout << "3. View Maintenance Records\n";
            cout << "4. Add Maintenance Record\n";
            cout << "5. View Analytics Report\n";
            cout << "6. Optimize Route\n";
            cout << "7. Log out\n";
            cout << "Enter your choice: ";
            cin >> adminChoice;

            if (adminChoice == 1) {
                string trainID, departure, arrival;
                bool isVIP;
                cout << "Enter Train ID: ";
                cin >> trainID;
                cout << "Enter Departure Time: ";
                cin >> departure;
                cout << "Enter Arrival Time: ";
                cin >> arrival;
                cout << "Is it a VIP Train? (1 for Yes, 0 for No): ";
                cin >> isVIP;
                trainScheduler.addTrainSchedule(trainID, departure, arrival, isVIP);
            } else if (adminChoice == 2) {
                revenueSystem.displayRevenueRecords();
            } else if (adminChoice == 3) {
                maintenanceSystem.displayMaintenanceRecords();
            } else if (adminChoice == 4) {
                string recordID, trainID, date, description;
                cout << "Enter Record ID: ";
                cin >> recordID;
                cout << "Enter Train ID: ";
                cin >> trainID;
                cout << "Enter Date: ";
                cin >> date;
                cout << "Enter Description: ";
                cin.ignore();
                getline(cin, description);
                maintenanceSystem.addMaintenanceRecord(recordID, trainID, date, description);
            } else if (adminChoice == 5) {
                analytics.generateReport();
            } else if (adminChoice == 6) {
                int sourceStation = 0; // Example: Karachi (index 0)
                routeOptimizer.optimizeRoute(sourceStation); // Pass the source station
            } else if (adminChoice == 7) {
                isAdminLoggedIn = false;
                cout << "Admin logged out successfully." << endl;
            } else {
                break;
            }

        } else if (choice == 3) {
            break;
        } else {
            cout << "Invalid choice! Try again.\n";
        }
    }

    return 0;
}

