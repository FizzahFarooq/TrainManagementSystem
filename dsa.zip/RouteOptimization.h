#ifndef ROUTEOPTIMIZATION_H
#define ROUTEOPTIMIZATION_H

#include <vector>
#include <iostream>
#include <queue>
#include <climits>

using namespace std;

class RouteOptimization {
private:
    int V;  // Number of vertices (stations)
    vector<vector<pair<int, int> > > adjList;// Adjacency list for the graph

public:
    // Constructor to initialize graph with given number of vertices
    RouteOptimization(int vertices);

    // Add edge between two stations with given distance (weight)
    void addEdge(int u, int v, int weight);

    // Dijkstra's Algorithm to find shortest path from source to destination
    void dijkstra(int source);

    // Optimize route based on Dijkstra's algorithm
    void optimizeRoute(int source);
};

#endif // ROUTEOPTIMIZATION_H

