#include "AnalyticsAndReporting.h"

// Recursive insert function
Train* AnalyticsAndReporting::insert(Train* root, int trainNumber, int passengerCount, const string& scheduleDetails) {
    if (root == NULL) {
        return new Train(trainNumber, passengerCount, scheduleDetails);
    }
    if (trainNumber < root->trainNumber) {
        root->left = insert(root->left, trainNumber, passengerCount, scheduleDetails);
    } else if (trainNumber > root->trainNumber) {
        root->right = insert(root->right, trainNumber, passengerCount, scheduleDetails);
    }
    return root;
}

// Recursive search function
Train* AnalyticsAndReporting::search(Train* root, int trainNumber) {
    if (root == NULL || root->trainNumber == trainNumber) {
        return root;
    }
    if (trainNumber < root->trainNumber) {
        return search(root->left, trainNumber);
    }
    return search(root->right, trainNumber);
}

// In-order traversal to display the tree in sorted order
void AnalyticsAndReporting::inOrderTraversal(Train* root) {
    if (root != NULL) {
        inOrderTraversal(root->left);
        cout << "Train Number: " << root->trainNumber
             << ", Passengers: " << root->passengerCount
             << ", Schedule: " << root->scheduleDetails << endl;
        inOrderTraversal(root->right);
    }
}

// Helper function to find minimum node in the BST
Train* AnalyticsAndReporting::findMin(Train* root) {
    if (root == NULL) return NULL;
    while (root->left != NULL) {
        root = root->left;
    }
    return root;
}

// Recursive delete function
Train* AnalyticsAndReporting::deleteNode(Train* root, int trainNumber) {
    if (root == NULL) {
        return root;
    }
    if (trainNumber < root->trainNumber) {
        root->left = deleteNode(root->left, trainNumber);
    } else if (trainNumber > root->trainNumber) {
        root->right = deleteNode(root->right, trainNumber);
    } else {
        if (root->left == NULL) {
            Train* temp = root->right;
            delete root;
            return temp;
        } else if (root->right == NULL) {
            Train* temp = root->left;
            delete root;
            return temp;
        }

        Train* temp = findMin(root->right);
        root->trainNumber = temp->trainNumber;
        root->passengerCount = temp->passengerCount;
        root->scheduleDetails = temp->scheduleDetails;
        root->right = deleteNode(root->right, temp->trainNumber);
    }
    return root;
}

// Destructor to clean up memory
void AnalyticsAndReporting::deleteTree(Train* node) {
    if (node == NULL) return;
    deleteTree(node->left);
    deleteTree(node->right);
    delete node;
}

AnalyticsAndReporting::AnalyticsAndReporting() : root(NULL) {}

AnalyticsAndReporting::~AnalyticsAndReporting() {
    deleteTree(root);
}

// Function to insert a new train node
void AnalyticsAndReporting::addTrain(int trainNumber, int passengerCount, const string& scheduleDetails) {
    root = insert(root, trainNumber, passengerCount, scheduleDetails);
}

// Function to search for a train by its number
void AnalyticsAndReporting::searchTrain(int trainNumber) {
    Train* result = search(root, trainNumber);
    if (result != NULL) {
        cout << "Train found: Train Number: " << result->trainNumber
             << ", Passengers: " << result->passengerCount
             << ", Schedule: " << result->scheduleDetails << endl;
    } else {
        cout << "Train not found!" << endl;
    }
}

// Function to delete a train
void AnalyticsAndReporting::removeTrain(int trainNumber) {
    root = deleteNode(root, trainNumber);
    cout << "Train with number " << trainNumber << " removed." << endl;
}

// Function to generate a report of all trains (in sorted order)
void AnalyticsAndReporting::generateReport() {
    cout << "Train Analytics Report (Sorted by Train Number):" << endl;
    inOrderTraversal(root);
}

