#ifndef ANALYTICS_AND_REPORTING_H
#define ANALYTICS_AND_REPORTING_H

#include <iostream>
#include <string>
using namespace std;

class Train {
public:
    int trainNumber;
    int passengerCount;
    string scheduleDetails;
    Train* left;
    Train* right;

    Train(int trainNumber, int passengerCount, const string& scheduleDetails)
        : trainNumber(trainNumber), passengerCount(passengerCount), scheduleDetails(scheduleDetails), left(NULL), right(NULL) {}
};

class AnalyticsAndReporting {
private:
    Train* root;

    Train* insert(Train* root, int trainNumber, int passengerCount, const string& scheduleDetails);
    Train* search(Train* root, int trainNumber);
    void inOrderTraversal(Train* root);
    Train* findMin(Train* root);
    Train* deleteNode(Train* root, int trainNumber);
    void deleteTree(Train* node);

public:
    AnalyticsAndReporting();
    ~AnalyticsAndReporting();

    void addTrain(int trainNumber, int passengerCount, const string& scheduleDetails);
    void searchTrain(int trainNumber);
    void removeTrain(int trainNumber);
    void generateReport();
};

#endif // ANALYTICS_AND_REPORTING_H

