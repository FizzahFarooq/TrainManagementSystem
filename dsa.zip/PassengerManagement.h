#ifndef PASSENGERMANAGEMENT_H
#define PASSENGERMANAGEMENT_H

#include <string>
using namespace std;

// Define the PassengerNode class
class PassengerNode {
public:
    string ticketID;
    string passengerName;
    string seatNumber;
    PassengerNode* next;

    PassengerNode(string ticketID, string passengerName, string seatNumber);
};

// Define the PassengerManagement class
class PassengerManagement {
private:
    PassengerNode* head;
    int size;

public:
    PassengerManagement();

    // Add a passenger to the list
    void addPassenger(string ticketID, string passengerName, string seatNumber);

    // Remove a passenger by ticket ID
    void removePassenger(string ticketID);

    // Update passenger information
    void updatePassengerInfo(string ticketID, string newName, string newSeatNumber);

    // Search for a passenger by ticket ID
    PassengerNode* searchPassenger(string ticketID);

    // Display all passengers' information
    void displayAllPassengers() const;

    // Get the number of passengers
    int getPassengerCount() const;

    // Check if the list is empty
    bool isEmpty() const;

    // Destructor to clean up the memory
    ~PassengerManagement();
};

#endif // PASSENGERMANAGEMENT_H

