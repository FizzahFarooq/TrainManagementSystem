#include "PassengerManagement.h"
#include <iostream>

PassengerNode::PassengerNode(string ticketID, string passengerName, string seatNumber)
    : ticketID(ticketID), passengerName(passengerName), seatNumber(seatNumber), next(NULL) {}

PassengerManagement::PassengerManagement() : head(NULL), size(0) {}

void PassengerManagement::addPassenger(string ticketID, string passengerName, string seatNumber) {
    PassengerNode* newPassenger = new PassengerNode(ticketID, passengerName, seatNumber);
    if (head == NULL) {
        head = newPassenger;
    } else {
        PassengerNode* current = head;
        while (current->next != NULL) {
            current = current->next;
        }
        current->next = newPassenger;
    }
    size++;
}

void PassengerManagement::removePassenger(string ticketID) {
    if (head == NULL) {
        cout << "No passengers to remove." << endl;
        return;
    }

    if (head->ticketID == ticketID) {
        PassengerNode* temp = head;
        head = head->next;
        delete temp;
        size--;
        return;
    }

    PassengerNode* current = head;
    while (current->next != NULL && current->next->ticketID != ticketID) {
        current = current->next;
    }

    if (current->next == NULL) {
        cout << "Passenger not found." << endl;
        return;
    }

    PassengerNode* temp = current->next;
    current->next = current->next->next;
    delete temp;
    size--;
}

void PassengerManagement::updatePassengerInfo(string ticketID, string newName, string newSeatNumber) {
    PassengerNode* current = head;
    while (current != NULL) {
        if (current->ticketID == ticketID) {
            current->passengerName = newName;
            current->seatNumber = newSeatNumber;
            return;
        }
        current = current->next;
    }
    cout << "Passenger not found." << endl;
}

PassengerNode* PassengerManagement::searchPassenger(string ticketID) {
    PassengerNode* current = head;
    while (current != NULL) {
        if (current->ticketID == ticketID) {
            return current;
        }
        current = current->next;
    }
    return NULL; // Return NULL if passenger is not found
}

void PassengerManagement::displayAllPassengers() const {
    if (head == NULL) {
        cout << "No passengers available." << endl;
        return;
    }

    PassengerNode* current = head;
    cout << "Passenger Information: " << endl;
    while (current != NULL) {
        cout << "Ticket ID: " << current->ticketID << ", Name: " << current->passengerName
             << ", Seat Number: " << current->seatNumber << endl;
        current = current->next;
    }
}

int PassengerManagement::getPassengerCount() const {
    return size;
}

bool PassengerManagement::isEmpty() const {
    return head == NULL;
}

PassengerManagement::~PassengerManagement() {
    while (head != NULL) {
        PassengerNode* temp = head;
        head = head->next;
        delete temp;
    }
}

