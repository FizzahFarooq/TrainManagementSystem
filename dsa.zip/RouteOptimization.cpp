#include "RouteOptimization.h"

// Constructor to initialize graph with given number of vertices
RouteOptimization::RouteOptimization(int vertices) {
    V = vertices;
    adjList.resize(vertices);
}

// Add edge between two stations with given distance (weight)
void RouteOptimization::addEdge(int u, int v, int weight) {
    adjList[u].push_back(pair<int, int>(v, weight));
    adjList[v].push_back(pair<int, int>(u, weight));

}

// Dijkstra's Algorithm to find shortest path from source to destination
void RouteOptimization::dijkstra(int source) {
    vector<int> dist(V, INT_MAX);  // distance from source to each station
    vector<bool> visited(V, false);
    dist[source] = 0;

    // Priority Queue to get the station with the minimum distance
    priority_queue<pair<int, int>, vector<pair<int, int> >, greater<pair<int, int> > > pq;


    pq.push(std::make_pair(0, source));


    while (!pq.empty()) {
        int u = pq.top().second;  // station with the minimum distance
        pq.pop();

        if (visited[u]) continue;
        visited[u] = true;

        // Update the distances for all adjacent stations
        for (int i = 0; i < adjList[u].size(); ++i) {
            int v = adjList[u][i].first;
            int weight = adjList[u][i].second;

            if (!visited[v] && dist[u] + weight < dist[v]) {
                dist[v] = dist[u] + weight;
                pq.push(std::make_pair(dist[v], v));

            }
        }
    }

    // Display shortest distance to all stations
    cout << "Shortest distance from source station " << source << ":" << endl;
    for (int i = 0; i < V; ++i) {
        if (dist[i] == INT_MAX) {
            cout << "Station " << i << " is unreachable." << endl;
        } else {
            cout << "To station " << i << ": " << dist[i] << endl;
        }
    }
}

// Function to optimize route, here we simply call dijkstra
void RouteOptimization::optimizeRoute(int source) {
    // You can add any other optimization logic here if needed
    dijkstra(source);
}

