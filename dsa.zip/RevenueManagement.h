#ifndef REVENUE_MANAGEMENT_H
#define REVENUE_MANAGEMENT_H

#include <string>
#include <iostream>
using namespace std;

// Structure for Revenue Record
struct RevenueRecord {
    string trainID;
    string travelDate;
    double revenue;
    RevenueRecord* left;
    RevenueRecord* right;
    int height;

    RevenueRecord(string tID, string tDate, double rev)
        : trainID(tID), travelDate(tDate), revenue(rev), left(NULL), right(NULL), height(1) {}
};

// AVL Tree class to handle Revenue Records
class RevenueManagement {
private:
    RevenueRecord* root;

    // Private helper methods
    int getHeight(RevenueRecord* node);
    void updateHeight(RevenueRecord* node);
    int getBalance(RevenueRecord* node);
    RevenueRecord* rightRotate(RevenueRecord* y);
    RevenueRecord* leftRotate(RevenueRecord* x);
    RevenueRecord* insert(RevenueRecord* node, string tID, string tDate, double rev);
    RevenueRecord* search(RevenueRecord* node, string tID);
    void inorder(RevenueRecord* root);
    void deallocate(RevenueRecord* node);

public:
    RevenueManagement();
    void insertRevenueRecord(string tID, string tDate, double rev);
    void searchRevenueRecord(string tID);
    void displayRevenueRecords();
    ~RevenueManagement();
};

#endif // REVENUE_MANAGEMENT_H

