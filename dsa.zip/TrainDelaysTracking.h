#ifndef TRAINDELAYS_H
#define TRAINDELAYS_H

#include <iostream>
using namespace std;

// Node structure for AVL Tree
struct Node {
    int trainNumber;
    int delayMinutes;
    Node* left;
    Node* right;
    int height;

    Node(int number, int delay);
};

// AVL Tree class for tracking train delays
class TrainDelaysTracking {
private:
    Node* root;

    int height(Node* node);
    int balanceFactor(Node* node);
    Node* rightRotate(Node* y);
    Node* leftRotate(Node* x);
    Node* insert(Node* node, int trainNumber, int delayMinutes);
    Node* minValueNode(Node* node);
    Node* deleteNode(Node* root, int trainNumber);
    Node* search(Node* root, int trainNumber);
    void inOrder(Node* root);
    void destroyTree(Node* node);

public:
    TrainDelaysTracking();
    void insertDelay(int trainNumber, int delayMinutes);
    void deleteDelay(int trainNumber);
    void searchDelay(int trainNumber);
    void displayAllDelays();
    ~TrainDelaysTracking();
};

#endif // TRAINDELAYS_H

