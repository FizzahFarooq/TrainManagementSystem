#include "AdminLogin.h"

// Simple method to validate login credentials (for demo purposes)
bool AdminLogin::validateCredentials(string username, string password) {
    return (username == "admin" && password == "password123");
}

// Method to log in
bool AdminLogin::login(string username, string password) {
    if (validateCredentials(username, password)) {
        if (top < 9) {  // Ensure the array doesn't overflow
            top++;
            loginAttempts[top] = username;  // Store successful login attempt
            cout << "Login successful." << endl;
            return true;
        }
        else {
            cout << "Login attempt limit reached." << endl;
            return false;
        }
    } else {
        cout << "Invalid username or password." << endl;
        return false;
    }
}

// Method to view last login attempt
void AdminLogin::viewLastLogin() {
    if (top != -1) {
        cout << "Last login attempt by: " << loginAttempts[top] << endl;
    } else {
        cout << "No login attempts yet." << endl;
    }
}

// Method to "undo" a login attempt
void AdminLogin::undoLogin() {
    if (top != -1) {
        cout << "Undoing last login attempt by: " << loginAttempts[top] << endl;
        top--;  // Remove the most recent login attempt
    } else {
        cout << "No login attempts to undo." << endl;
    }
}

