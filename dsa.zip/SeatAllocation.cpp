#include "SeatAllocation.h"

// Constructor for Seat struct
Seat::Seat(int id) : seatID(id), isOccupied(false), passengerName("") {}

// Constructor to initialize the circular linked list with a fixed number of seats
SeatAllocation::SeatAllocation(int seats) {
    totalSeats = seats;
    head = NULL;
    tail = NULL;

    // Create and link all seats in a circular manner
    for (int i = 1; i <= seats; ++i) {
        Seat* newSeat = new Seat(i);
        Node* newNode = new Node(newSeat);

        if (!head) {
            head = tail = newNode;
        } else {
            tail->next = newNode;
            tail = newNode;
        }
        tail->next = head;  // Make it circular
    }
}

// Function to allocate a seat to a passenger
void SeatAllocation::allocateSeat(string passengerName) {
    if (!head) {
        cout << "No seats available!" << endl;
        return;
    }

    // Find the first available seat (the first unoccupied seat)
    Node* current = head;
    do {
        if (!current->seat->isOccupied) {
            current->seat->isOccupied = true;
            current->seat->passengerName = passengerName;
            cout << "Seat " << current->seat->seatID << " has been allocated to " << passengerName << "." << endl;
            return;  // Seat allocated, exit function
        }
        current = current->next;
    } while (current != head);

    cout << "Sorry, all seats are occupied." << endl;
}

// Function to deallocate a seat (when a passenger cancels or exits)
void SeatAllocation::deallocateSeat(int seatID) {
    if (!head) {
        cout << "No seats available!" << endl;
        return;
    }

    Node* current = head;
    do {
        if (current->seat->seatID == seatID && current->seat->isOccupied) {
            current->seat->isOccupied = false;
            current->seat->passengerName = "";
            cout << "Seat " << seatID << " has been deallocated." << endl;
            return;  // Seat deallocated, exit function
        }
        current = current->next;
    } while (current != head);

    cout << "Seat " << seatID << " is either not occupied or does not exist." << endl;
}

// Function to display all seats and their status
void SeatAllocation::displaySeats() {
    if (!head) {
        cout << "No seats available!" << endl;
        return;
    }

    Node* current = head;
    do {
        cout << "Seat " << current->seat->seatID
             << " - " << (current->seat->isOccupied ? "Occupied by " + current->seat->passengerName : "Available") << endl;
        current = current->next;
    } while (current != head);
}

// Destructor to clean up memory
SeatAllocation::~SeatAllocation() {
    if (!head) return;

    Node* current = head;
    do {
        Node* temp = current;
        current = current->next;
        delete temp->seat;
        delete temp;
    } while (current != head);
}

