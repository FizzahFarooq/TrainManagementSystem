#ifndef PASSENGER_H
#define PASSENGER_H

#include <string>

using namespace std;

struct Passenger {
    int id;               // ID of the passenger
    string name;          // Name of the passenger
    string contact;       // Contact information
    string ticketID;      // Ticket ID
    int seatNumber;       // Seat number
    string reservationTime;  // Reservation time
    Passenger* next;

    // Constructor to initialize a Passenger object
    Passenger(const string& ticket, const string& name, int seat, const string& reservationTime, Passenger* next = NULL)
        : ticketID(ticket), name(name), seatNumber(seat), reservationTime(reservationTime), next(next) {}
};

#endif

