#ifndef SEAT_ALLOCATION_H
#define SEAT_ALLOCATION_H

#include <string>
#include <iostream>

using namespace std;

// Define a structure to represent a Seat
struct Seat {
    int seatID;
    string passengerName;
    bool isOccupied;

    Seat(int id);
};

// Define the Circular Linked List for seat allocation
class SeatAllocation {
private:
    struct Node {
        Seat* seat;
        Node* next;

        Node(Seat* s);
    };

    Node* head;
    Node* tail;
    int totalSeats;

public:
    // Constructor to initialize the circular linked list with a fixed number of seats
    SeatAllocation(int seats);

    // Function to allocate a seat to a passenger
    void allocateSeat(string passengerName);

    // Function to deallocate a seat (when a passenger cancels or exits)
    void deallocateSeat(int seatID);

    // Function to display all seats and their status
    void displaySeats();

    // Destructor to clean up memory
    ~SeatAllocation();
};

#endif

