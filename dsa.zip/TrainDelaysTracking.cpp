#include "TrainDelaysTracking.h"
#include <algorithm>
using namespace std;

// Node constructor
Node::Node(int number, int delay) : trainNumber(number), delayMinutes(delay), left(NULL), right(NULL), height(1) {}

// Function to get the height of the node
int TrainDelaysTracking::height(Node* node) {
    return node ? node->height : 0;
}

// Function to calculate the balance factor of the node
int TrainDelaysTracking::balanceFactor(Node* node) {
    return node ? height(node->left) - height(node->right) : 0;
}

// Right rotation to balance the tree
Node* TrainDelaysTracking::rightRotate(Node* y) {
    Node* x = y->left;
    Node* T2 = x->right;

    x->right = y;
    y->left = T2;

    y->height = max(height(y->left), height(y->right)) + 1;
    x->height = max(height(x->left), height(x->right)) + 1;

    return x;  // Return new root
}

// Left rotation to balance the tree
Node* TrainDelaysTracking::leftRotate(Node* x) {
    Node* y = x->right;
    Node* T2 = y->left;

    y->left = x;
    x->right = T2;

    x->height = max(height(x->left), height(x->right)) + 1;
    y->height = max(height(y->left), height(y->right)) + 1;

    return y;  // Return new root
}

// Function to insert a new node and balance the tree
Node* TrainDelaysTracking::insert(Node* node, int trainNumber, int delayMinutes) {
    if (node == NULL) {
        return new Node(trainNumber, delayMinutes);
    }

    if (trainNumber < node->trainNumber) {
        node->left = insert(node->left, trainNumber, delayMinutes);
    } else if (trainNumber > node->trainNumber) {
        node->right = insert(node->right, trainNumber, delayMinutes);
    } else {
        node->delayMinutes = delayMinutes;
        return node;
    }

    node->height = 1 + max(height(node->left), height(node->right));

    int balance = balanceFactor(node);

    if (balance > 1 && trainNumber < node->left->trainNumber) {
        return rightRotate(node);
    }

    if (balance < -1 && trainNumber > node->right->trainNumber) {
        return leftRotate(node);
    }

    if (balance > 1 && trainNumber > node->left->trainNumber) {
        node->left = leftRotate(node->left);
        return rightRotate(node);
    }

    if (balance < -1 && trainNumber < node->right->trainNumber) {
        node->right = rightRotate(node->right);
        return leftRotate(node);
    }

    return node;
}

// Function to find the node with the minimum value
Node* TrainDelaysTracking::minValueNode(Node* node) {
    Node* current = node;
    while (current && current->left != NULL) {
        current = current->left;
    }
    return current;
}

// Function to delete a node and balance the tree
Node* TrainDelaysTracking::deleteNode(Node* root, int trainNumber) {
    if (root == NULL) {
        return root;
    }

    if (trainNumber < root->trainNumber) {
        root->left = deleteNode(root->left, trainNumber);
    } else if (trainNumber > root->trainNumber) {
        root->right = deleteNode(root->right, trainNumber);
    } else {
        if (root->left == NULL || root->right == NULL) {
            Node* temp = root->left ? root->left : root->right;
            if (temp == NULL) {
                temp = root;
                root = NULL;
            } else {
                *root = *temp;
            }
            delete temp;
        } else {
            Node* temp = minValueNode(root->right);
            root->trainNumber = temp->trainNumber;
            root->delayMinutes = temp->delayMinutes;
            root->right = deleteNode(root->right, temp->trainNumber);
        }
    }

    if (root == NULL) {
        return root;
    }

    root->height = 1 + max(height(root->left), height(root->right));

    int balance = balanceFactor(root);

    if (balance > 1 && balanceFactor(root->left) >= 0) {
        return rightRotate(root);
    }

    if (balance < -1 && balanceFactor(root->right) <= 0) {
        return leftRotate(root);
    }

    if (balance > 1 && balanceFactor(root->left) < 0) {
        root->left = leftRotate(root->left);
        return rightRotate(root);
    }

    if (balance < -1 && balanceFactor(root->right) > 0) {
        root->right = rightRotate(root->right);
        return leftRotate(root);
    }

    return root;
}

// Function to search for a train by number
Node* TrainDelaysTracking::search(Node* root, int trainNumber) {
    if (root == NULL || root->trainNumber == trainNumber) {
        return root;
    }

    if (trainNumber < root->trainNumber) {
        return search(root->left, trainNumber);
    } else {
        return search(root->right, trainNumber);
    }
}

// Function to print the tree in In-Order traversal
void TrainDelaysTracking::inOrder(Node* root) {
    if (root != NULL) {
        inOrder(root->left);
        cout << "Train " << root->trainNumber << " has a delay of " << root->delayMinutes << " minutes." << endl;
        inOrder(root->right);
    }
}

// Constructor
TrainDelaysTracking::TrainDelaysTracking() : root(NULL) {}

// Insert a new train delay
void TrainDelaysTracking::insertDelay(int trainNumber, int delayMinutes) {
    root = insert(root, trainNumber, delayMinutes);
}

// Delete a train delay
void TrainDelaysTracking::deleteDelay(int trainNumber) {
    root = deleteNode(root, trainNumber);
}

// Search for a train delay by train number
void TrainDelaysTracking::searchDelay(int trainNumber) {
    Node* result = search(root, trainNumber);
    if (result != NULL) {
        cout << "Train " << result->trainNumber << " has a delay of " << result->delayMinutes << " minutes." << endl;
    } else {
        cout << "Train " << trainNumber << " not found." << endl;
    }
}

// Display all train delays
void TrainDelaysTracking::displayAllDelays() {
    inOrder(root);
}

// Destructor
TrainDelaysTracking::~TrainDelaysTracking() {
    destroyTree(root);
}

// Helper function to delete nodes recursively
void TrainDelaysTracking::destroyTree(Node* node) {
    if (node != NULL) {
        destroyTree(node->left);
        destroyTree(node->right);
        delete node;
    }
}

