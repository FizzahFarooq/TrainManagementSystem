#ifndef ADMINLOGIN_H
#define ADMINLOGIN_H

#include <iostream>
#include <string>
using namespace std;

class AdminLogin {
private:
    string loginAttempts[10];  // Array to store login attempts
    int top = -1;              // To keep track of the top index

    // Simple method to validate login credentials (for demo purposes)
    bool validateCredentials(string username, string password);

public:
    // Method to log in
    bool login(string username, string password);

    // Method to view last login attempt
    void viewLastLogin();

    // Method to "undo" a login attempt
    void undoLogin();
};

#endif // ADMINLOGIN_H

