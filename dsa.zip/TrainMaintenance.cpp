#include "TrainMaintenance.h"
#include <iostream>
using namespace std;

// Constructor for MaintenanceRecord
MaintenanceRecord::MaintenanceRecord(string mID, string tID, string mDate, string desc)
    : maintenanceID(mID), trainID(tID), maintenanceDate(mDate), description(desc), next(NULL), prev(NULL) {}

// Constructor for TrainMaintenance
TrainMaintenance::TrainMaintenance() : head(NULL), tail(NULL) {}

// Add a new maintenance record at the end of the list
void TrainMaintenance::addMaintenanceRecord(string mID, string tID, string mDate, string desc) {
    MaintenanceRecord* newRecord = new MaintenanceRecord(mID, tID, mDate, desc);
    
    if (tail == NULL) {  // If the list is empty
        head = tail = newRecord;
    } else {
        tail->next = newRecord;
        newRecord->prev = tail;
        tail = newRecord;
    }
}

// Remove the most recent maintenance record (tail)
void TrainMaintenance::removeRecentMaintenance() {
    if (tail == NULL) {
        cout << "No maintenance records to remove." << endl;
        return;
    }

    MaintenanceRecord* temp = tail;
    tail = tail->prev;
    if (tail) {
        tail->next = NULL;
    } else {
        head = NULL;  // If the list is now empty
    }
    delete temp;
    cout << "Recent maintenance record removed." << endl;
}

// Display all maintenance records from the most recent to the oldest
void TrainMaintenance::displayMaintenanceRecords() {
    if (!head) {
        cout << "No maintenance records available." << endl;
        return;
    }

    MaintenanceRecord* temp = tail;
    while (temp) {
        cout << "Maintenance ID: " << temp->maintenanceID << endl;
        cout << "Train ID: " << temp->trainID << endl;
        cout << "Date: " << temp->maintenanceDate << endl;
        cout << "Description: " << temp->description << endl;
        cout << "----------------------------" << endl;
        temp = temp->prev;
    }
}

// Search for a specific maintenance record by its ID
void TrainMaintenance::searchMaintenanceRecordByID(string mID) {
    MaintenanceRecord* temp = head;
    while (temp) {
        if (temp->maintenanceID == mID) {
            cout << "Maintenance ID: " << temp->maintenanceID << endl;
            cout << "Train ID: " << temp->trainID << endl;
            cout << "Date: " << temp->maintenanceDate << endl;
            cout << "Description: " << temp->description << endl;
            return;
        }
        temp = temp->next;
    }
    cout << "Maintenance record not found." << endl;
}

// Update a maintenance record (based on maintenance ID)
void TrainMaintenance::updateMaintenanceRecord(string mID, string newDesc) {
    MaintenanceRecord* temp = head;
    while (temp) {
        if (temp->maintenanceID == mID) {
            temp->description = newDesc;
            cout << "Maintenance record updated." << endl;
            return;
        }
        temp = temp->next;
    }
    cout << "Maintenance record not found." << endl;
}

// Destructor to clean up the dynamically allocated memory
TrainMaintenance::~TrainMaintenance() {
    MaintenanceRecord* temp;
    while (head) {
        temp = head;
        head = head->next;
        delete temp;
    }
}

